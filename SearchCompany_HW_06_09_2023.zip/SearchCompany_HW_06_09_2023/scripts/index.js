const apiUrl = "https://jsonplaceholder.typicode.com/users/";

async function fetchUser(userId) {
  try {
    const response = await fetch(apiUrl + userId);
    if (!response.ok) {
      throw new Error("Not network response");
    }
    const userData = await response.json();
    return userData;
  } catch (error) {
    console.error("Error fetching user data:", error);
  }
}

const nameElement = document.getElementById("name");
const emailElement = document.getElementById("email");
const websiteElement = document.getElementById("website");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");

let userId = 1;

async function displayUser(userId) {
  const userData = await fetchUser(userId);
  if (userData) {
    nameElement.textContent = userData.name;
    emailElement.textContent = userData.email;
    websiteElement.textContent = userData.website;
  }
}

displayUser(userId);

prevBtn.addEventListener("click", () => {
  userId -= 1;
  if (userId < 1) {
    userId = 1;
  }
  displayUser(userId);
});

nextBtn.addEventListener("click", () => {
  userId += 1;
  displayUser(userId);
});
